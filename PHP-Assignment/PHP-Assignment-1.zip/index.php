<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Populated Search</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>


</head>
<body class="bg-warning">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 bg-light p-4 mt-3 rounded">
                <h4>Search Countries</h4>
                <!-- Form -->
                <form action="details.php" method="post" autocomplete="off" class="form-inline p-3">
                    <input type="text" name="search" id="search" 
                        class="form-control form-control-lg rounded-0 border-warning" placeholder="Search Here" 
                        style="width: 80%;">
                    <input type="submit" name="submit" value="Search"
                        class="btn btn-warning btn-lg rounded-0" style="width: 20%;">
                </form>
            </div>
            <div class="col-md-5" style="position: relative; margin-top:-38px; margin-left:215px;">
                <div class="list-group" id="show-list">
                   
                </div>
            </div>
            <!-- Multiselect -->
            <div class="col-md-8 offset-md-2 bg-light p-4 mt-3 rounded">
                <h4>Search Multiple Countries</h4>
                <!-- Form -->
                <form  autocomplete="off" class="form-inline p-3">
                    <input type="text" name="searchM" id="searchM" 
                        class="form-control form-control-lg rounded-0 border-warning" placeholder="Search Here" 
                        style="width: 80%;">
                        <button type="button" id="submit1" class="btn btn-warning btn-lg rounded-0" style="width: 20%; height:fit-content;" >Select</button>
                </form>
            </div>
            <div class="col-md-5" style="position: relative; margin-top:-38px; margin-left:215px;">
                <div class="list-group" id="multi-list">
                   
                </div>
            </div>

        </div>
    </div>
    <!-- Javascript and AJAX -->
    <script type="text/javascript">
        $(document).ready(function(){

            $("#search").keyup(function(){            //targeting the search textbox using id-------------
                var searchText = $(this).val();
                if(searchText!=''){
                    $.ajax({
                        url: 'action.php',
                        method: 'post',
                        data: {query:searchText},
                        success: function(response){
                            $("#show-list").html(response); //response coming from the server will be shown 
                        }
                    });
                }
                else{
                    $("#show-list").html('');
                }
            });

            $(document).on('click','a',function(){ //after selecting country-row
               $("#search").val($(this).text()); //it will set that data value in text box
               $("#show-list").html('');
            });

            $('#searchM').tokenfield({                
            autocomplete :{                           
                    source: function(request, response)         //call back function
                    {
                        jQuery.post('fetch.php',{
                            query : request.term
                        }, function(data){
                            data=JSON.parse(data);
                            response(data);
                        });                       
                    },
                    delay: 100
                }
            });
            
            $('#submit1').click(function(){ //for displaying multiple value in , format
                $('#multi-list').text($('#searchM').val());

            });

        });
    </script>
</body>
</html>