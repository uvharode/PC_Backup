<?php
$conn = new mysqli("localhost", "root","","php-auto");
if($conn->connect_error){
    die("Failed to connect".$conn->connect_error);
}
if(isset($_POST['submit'])){  //check if submit is clicked
  
    $data=$_POST['search'];  //store the searched data of textbox
    $sql="SELECT * FROM auto_comp WHERE country='$data' ";
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();
    
    echo "ID: ".$row['id']."<br>";
    echo "Country Name: ".$row['country'];
}

?>