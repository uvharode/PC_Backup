<?php
    $conn = new mysqli("localhost", "root","","php-auto");
    if($conn->connect_error){
        die("Failed to connect".$conn->connect_error);
    }

    $data = array();
    if(isset($_POST['query']))
    {
        $inpText=$_POST['query'];
        $query="SELECT country FROM auto_comp WHERE country LIKE '%$inpText%' ";
        $result = $conn->query($query);

        if($result->num_rows>0)
        {
            while($row = $result->fetch_assoc())   //result into array format
            {
                $data[] = $row["country"];
            }
            echo json_encode($data);
        }
    
    }
    
?>